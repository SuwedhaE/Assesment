package com.demo.capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringCrudOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudOperationApplication.class, args);
	}

}
