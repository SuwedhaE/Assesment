package com.demo.capstone.repository;

import org.springframework.data.repository.CrudRepository;

import com.demo.capstone.Entity.Citizens;

public interface UserRepo extends CrudRepository<Citizens, Integer>{
	
	
}
