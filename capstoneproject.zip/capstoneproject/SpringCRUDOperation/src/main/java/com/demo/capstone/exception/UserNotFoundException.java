package com.demo.capstone.exception;

public class UserNotFoundException extends RuntimeException {
	public UserNotFoundException(int id) {
		super("Citizen with id " + id + " is not Found.Pls Give another id!!");
	}

}
