package Innerclass;
public class innerclass {
void Check(String locker_key) {
		if(locker_key.equals("abc@gmail.com")) {	
			class Inner {
				void validate() {
					System.out.println("Validated");
				}
			}	
			Inner inner= new Inner();
			inner.validate();
		}
		else {
			
			System.out.println("Not Valid");
		}			
	}	
	public static void main(String[] args) {
		
		innerclass outer= new innerclass();
		outer.Check("abc@gmail.com");		
	}
}
