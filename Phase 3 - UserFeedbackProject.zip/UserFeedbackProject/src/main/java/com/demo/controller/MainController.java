package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.FeedbackDao;
import com.demo.FeedbackEntity;

@RestController
public class MainController {
	
	@Autowired
	FeedbackDao dao;
	
	@PostMapping("/feedback")
	public FeedbackEntity addNewFeedback(@RequestBody FeedbackEntity fb) {
		FeedbackEntity newfb = FeedbackEntity();
		fb.getName();
		fb.getEmail();
		fb.getFeedback();
		System.out.print("<h2>Product Successfully Added !</h2>");
		return newfb;
		
		
	}

	private FeedbackEntity FeedbackEntity() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
