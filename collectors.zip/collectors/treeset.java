package collectors;
import java.util.Set;
import java.util.TreeSet;

public class treeset {
	public static void main(String[] args) {
	
		Set<String> set = new TreeSet<String>(); 
		
		set.add("Red");
		set.add("Black");
		set.add("Green");
		set.add("Red");
		//set.add(null);
		
		System.out.println(set);
		
		System.out.println("Size: "+set.size());
		
		System.out.println("Contains: "+ set.contains("Black"));
		
	}
}
