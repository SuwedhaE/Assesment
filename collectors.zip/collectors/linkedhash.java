package collectors;
import java.util.LinkedHashSet;

public class linkedhash {
	public static void main(String[] args) {
		
		LinkedHashSet<String> linkedset= new LinkedHashSet<String>();
		
		linkedset.add("A");
		linkedset.add("B");
		linkedset.add("C");
		linkedset.add("D");
		
		//do not allows duplicate values
		linkedset.add("A");
		linkedset.add("E");
		linkedset.add(null);
		
		System.out.println("Size: "+linkedset.size());
		
		System.out.println(linkedset);
		
		
		System.out.println("Contains E: "+linkedset.contains("E"));
		
		linkedset.remove(null);
		
		System.out.println("After Remove: "+linkedset);
		
	}
}
