package collectors;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;
public class vectorprog {
	public static void main(String[] args) {
		Vector<String> list= new Vector<String>();
		System.out.println("Size:"+list.size());

		list.add("Red");
		list.add("Black");
		list.add("Green");
		list.add("Violet");
		list.add(null);

		System.out.println("After Adding an Elements :"+list.size());
		System.out.println(list);

		System.out.println("Element at index 4: "+list.get(4));
		list.add("Orange");

		System.out.println(list);

		System.out.println("List Contains Red? :"+list.contains("Red"));


		list.remove(0);
		list.remove(null);

		System.out.println(list);


		//print a list using for loop

		for(String s:list) {
			System.out.println("Using For Loop: "+s);
		}


		//iterate using iterator
		Iterator<String> itr= list.iterator();

		while(itr.hasNext()) {
			System.out.println("Using Iterator: "+itr.next());
		}

	}
}
