package collectors;
import java.util.HashSet;

public class sethash {		
		public static void main(String[] args) {
			
			HashSet<Integer> set= new HashSet<Integer>();
			
			set.add(201);
			set.add(55);
			set.add(298);
			set.add(364);
			set.add(57);
			set.add(57);
			set.add(null);
			
			System.out.println("Size: "+set.size());
			
			System.out.println(set);
			
			System.out.println("Contains: "+ set.contains(367));
			
			set.remove(null);
			
		}

	}

