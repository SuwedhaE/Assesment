package collectors;
import java.util.LinkedList;
import java.util.PriorityQueue;
public class Priorityqueue {
	public static void main(String[] args) {

		PriorityQueue<Integer> pQueue= new PriorityQueue<Integer>(); 

		pQueue.add(06);
		pQueue.add(00);
		pQueue.add(96);
		pQueue.add(13);

		System.out.println(pQueue);

		System.out.println("Top Element: " + pQueue.peek());

		System.out.println("Printing the top element and removing: "+pQueue.poll());
		System.out.println(pQueue);

		System.out.println("Top Element: " + pQueue.peek());

		pQueue.remove(6);

		System.out.println("After Remove : "+pQueue);

	}

}
