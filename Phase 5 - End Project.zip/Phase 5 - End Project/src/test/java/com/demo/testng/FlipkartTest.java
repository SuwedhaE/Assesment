package com.demo.testng;

import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FlipkartTest {

	WebDriver driver;

	@Test
	public void filpcart() {

		driver.get("https://www.flipkart.com/");		
		Actions actions = new Actions(driver);
		Action sendEsc = actions.sendKeys(Keys.ESCAPE).build() ;
		sendEsc.perform();
		
		long startTime = System.currentTimeMillis();
		driver.get("https://www.flipkart.com/");
		long EndTime = System.currentTimeMillis();
		long totalTime = EndTime - startTime;
		System.out.println("\nPage LoadTime : " + totalTime);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
						
		WebElement element1= driver.findElement(By.cssSelector("#container > div > div._331-kn._2tvxW > div > div > div:nth-child(3) > a > div._1mkliO"));
		element1.click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		driver.findElement(By.name("q")).sendKeys("iphone13");
		driver.findElement(By.className("L0Z3Pu")).click();
		
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		WebElement image = driver.findElement(By.xpath(
				"/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/a[1]/div[1]/div[1]/div[1]/div[1]/img[1]"));
		Object result = ((JavascriptExecutor) driver).executeScript("return arguments[0].complete && "
				+ "typeof arguments[0].naturalWidth != \"undefined\" && " + "arguments[0].naturalWidth > 0", image);

		boolean loaded = false;
		if (result instanceof Boolean) {
			loaded = (Boolean) result;
			System.out.println("Image Loaded = " + loaded);
		}
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		WebElement element = driver.findElement(By.xpath(
				"/html[1]/body[1]/div[1]/div[1]/div[3]/div[1]/div[2]/div[6]/div[1]/div[1]/div[1]/a[1]/div[1]/div[1]/div[1]/div[1]/img[1]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);

		System.out.println(element.getText());
		System.out.println("Page has a scroll feature");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		System.out.println("Navigation of page to the bottom of the page Successfull !!!");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		long startreftime= System.currentTimeMillis();
		driver.navigate().refresh();
		long endreftime= System.currentTimeMillis();
		long totalreftime = endreftime - startreftime;
		System.out.println("Page refresh time : " + totalreftime + "ms");

	}
        

	@BeforeMethod
	public void beforeMethod() {

		System.setProperty("webdriver.chrome.driver", "C:\\Phase-5\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		System.out.println("Chrome opened successfully !");
		
		/*System.setProperty("webdriver.edge.driver", "C:\\Phase-5\\edgedriver_win64\\msedgedriver.exe");
		driver = new EdgeDriver();
		System.out.println("Edge opened successfully !");
		
		
		System.setProperty("webdriver.gecko.driver", "C:\\Phase-5\\geckodriver-v0.31.0-win64\\geckodriver.exe");
		driver = new FirefoxDriver();
		System.out.println("Firefox opened successfully !");*/
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		
	}
	
	@AfterMethod
	public void closeBrowser() {
		driver.quit();
		System.out.println("Chrome has been automaticcaly closed !");
		//System.out.println("Edge has been automaticcaly closed !");
		//System.out.println("Firefox has been automaticcaly closed !");
	}

}
