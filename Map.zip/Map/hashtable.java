package Map;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class hashtable {
public static void main(String[] args) {
		
		Hashtable<Integer, String>  map= new Hashtable<Integer, String>();
		
		map.put(1, "Hockey");
		map.put(2, "Cricket");
		map.put(3, "Tennis");
		
		//do not allows null value
		//map.put(null, "koko");
		//map.put(4, null);
		
		System.out.println(map);
		
		System.out.println("Get element at key 3: "+map.get(3));
		
		System.out.println("Get element at key 4: "+map.get(5));
		
		System.out.println("Get element at key 5: "+map.get(5));
		
		map.remove(3);
		
		System.out.println(map);
		
		///iterate using for loop
		
		for(Map.Entry m: map.entrySet()) {
			
			System.out.println(m.getKey()+" , "+m.getValue());
		}				
	}
}


