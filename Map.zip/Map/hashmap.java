package Map;
import java.util.HashMap;
import java.util.Map;

public class hashmap {
	public static void main(String[] args) {
		HashMap<Integer,String> map=new HashMap<Integer,String>();
		
		map.put(null, null);
		map.put(null, "string");
		map.put(1, null);
		map.put(2, "null");
		map.put(3, "Apple");
		map.put(4, "Dora");		
		map.put(5, "Bujji");		
		map.put(6, "Orange");
		
		System.out.println(map);
		
		System.out.println("Get element at key 3: "+map.get(3));
		
		System.out.println("Get element at key 1: "+map.get(1));
		
		System.out.println("Get element at key null: "+map.get(null));//as key is null value soni is not added in map
		
		map.remove(5);
		
		System.out.println(map);
	
	    //for loop
	    for (Map.Entry m:map.entrySet()){
	    	System.out.println(m.getKey()+","+m.getValue());
	    	}
	}
}
