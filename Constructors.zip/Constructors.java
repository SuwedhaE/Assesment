package session1;

public class Constructors {
	String SareeName;
	float cost;
	int quantity;
	String colour;
	
	public Constructors(){
		SareeName="Banaras saree";
		cost = 25000;
		quantity =5;
		colour="Red";
	}
	public Constructors(String SareeName,int cost,int quantity,String colour) {
		this.SareeName = SareeName;
		this.cost = cost;
		this.quantity=quantity;
		this.colour=colour;
	}
	
	public void display() {
		System.out.println("SareeName: "+SareeName);
		System.out.println("cost: "+cost);
		System.out.println("quantity: "+quantity);
		System.out.println("colour: "+colour);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		Constructors c= new Constructors();
		Constructors c1= new Constructors("Designer Sarees",45000,15,"Purple with green"); 

		//calling default constructor
		c.display();
		//parametrized constructor
		c1.display();	
	} 
}