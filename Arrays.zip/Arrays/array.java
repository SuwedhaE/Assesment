package Arrays;

public class array {
	public static void main(String[] args) {
		int array[]= {11,22,33,44,55,77};
		
		System.out.println("Element at index 5: "+ array[5]);
		
		System.out.println("Length of an Array: "+array.length);
		
		System.out.println("Access using for loopp");
		
		for (int i=0;i<array.length;i++) {
			
			System.out.println(array[i]);
			
		}
		
		System.out.println();
		
		
		for(int a: array) {
			System.out.print(a+ " ");
		}
	}
}
