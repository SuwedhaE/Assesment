package session1;

public class methods {
	int area(int a) {
		return (a*a);		
	}
	double area(double r) {
		return (3.14*r*r);
	}
	public static void main(String[] args) {
		methods op = new methods();
		System.out.println("Area of Square = "+ op.area(6));
		
		System.out.println("Area of circle = "+ op.area(9.0));
	}

}

// in class there is no void function , but it has return type . 
//same function with different parametr is call method overloading.
