package session1;

public class method1 {
	public static void main(String[] args) {
	int a=25;
	int b=20;
	System.out.println("Before swapping, a = " + a + " and b = " + b);
	swapFunction(a,b);
	System.out.println("Returned to original form, a = " + a + " and b = " + b);
	}
	public static void swapFunction(int a, int b) {
		int c=a;
	    a=b;
		b=c;
		System.out.println("After swapping, a = " + a + " and b = " + b);
	}
}
	//it has void in class.same two value is called in swap funtion .
    // but the output is different .
	

