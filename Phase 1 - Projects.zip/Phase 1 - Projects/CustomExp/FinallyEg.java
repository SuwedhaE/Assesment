
public class FinallyEg {
	public static void main(String[] args) {
		try {
			int div;
			div = 5/0 ;
			System.out.println("The output is : " + div);
		} 
		catch (Exception e) {
			System.out.println("Exception Handling");
		} 
		finally {
			System.out.println("Arithmetic Exception ");
		}
		System.out.println("The Program runned successfully");		
	}
}
