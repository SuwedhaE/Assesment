
public class ThrowEg {
	public static void checkNum(int num) {
		if(num < 1) {
			throw new ArithmeticException("The number given is negative");
		}
		else {
			System.out.println("The number is positive");
		}
	}
	public static void main(String[] args) {
		ThrowEg op = new ThrowEg();
		op.checkNum(-5);
		System.out.println("Program runned successfully ... ");
	}
}
