
public class ThrowsEg {
	public static int product(int n1 , int n2)throws ArithmeticException{
		int mul = n1*n2;
		return mul;
	}
	public static void main(String[] args) {
		ThrowsEg op = new ThrowsEg();
		try {
			System.out.println(op.product(15,0));
		} catch (ArithmeticException e) {
			System.out.println("The output is zero");
		}
		System.out.println("Error Occured");
	}
}
