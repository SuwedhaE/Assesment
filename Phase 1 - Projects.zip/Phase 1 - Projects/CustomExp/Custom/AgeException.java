package Practice;

public class AgeException extends Exception{
	private static final long serialVersionUID = 1L;
	private String msg;
	public AgeException(String msg) {
		this.msg=msg;
	}
	@Override
	public String toString() {
		return "AgeException [msg=" + msg + "]";
	}
	
}
