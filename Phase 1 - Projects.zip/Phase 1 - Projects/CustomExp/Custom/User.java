package Practice;

public class User {
	static void check(int age) throws AgeException{
		if (age>=18) {
			System.out.println("Eligible to vote");
		}
		else {
			System.out.println("Not Eligible to vote");
		}
	}
	public static void main(String[] args) {
		 try {
			check (11);
		} catch (AgeException e) {
			e.printStackTrace();
		}
		
	}
}
