package Practice;

import java.io.File;
import java.io.FileWriter;

public class CreateFile {
	public static void createFileUsingFileClass() throws Exception{
		File file = new File("D:\\files\\testFile22-07-22.txt");
		if(file.createNewFile()) {
			System.out.println("File is Created");
		}
		else {
			System.out.println("File exits");
		}
		FileWriter writer = new FileWriter(file, false);
		writer.write("Hi!... Good Morning");
		writer.close();
	}
	public static void main(String[] args) {
		try {
			createFileUsingFileClass();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
