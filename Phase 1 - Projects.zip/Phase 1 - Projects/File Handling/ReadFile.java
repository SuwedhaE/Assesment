package Practice;

import java.io.FileReader;

public class ReadFile {
	public static void readFileReaderClass() throws Exception{
		try (FileReader reader = new FileReader("D:\\files\\testFile22-07-22.txt")) {
			int data;
			while((data=reader.read())!=-1){
				System.out.print((char)data);
			}
		}
	}
	public static void main(String[] args) {
		try {
			readFileReaderClass();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Can't be read");
		}
	}
}
