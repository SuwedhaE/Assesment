
public class ClassObj {
	private static final String Redmi = null;
	private static final String A9 = null;
	int id;
	String name;
	String Model;
	int Mobile;
	
	public ClassObj(int id, String name, String model, int Mobile) {
		this.id = id;
		this.name = name;
		this.Model = model;
		this.Mobile = Mobile;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getModel() {
		return Model;
	}

	public int getMobile() {
		return Mobile;
	}

	@Override
	public String toString() {
		return "ClassObj [id=" + id + ", name=" + name + ", Model=" + Model + ", Mobile=" + Mobile + "]";
	}

	public static void main(String[] args) {
		ClassObj CO = new ClassObj(5, Redmi, A9, 35999);
		System.out.println(CO.toString());
	}
	


}
