
public class Mul {
	public int mul(int a , int b) {
		return (a*b);
	}
	public float mul(float a,float b) {
		return (a*b);
	}
	public double mul(double a,double b) {
		return (a*b);
	}
	public static void main(String[] args) {
		Mul m = new Mul();
		System.out.println(m.mul(2, 3));
		System.out.println(m.mul(5.0 , 5.0));
		System.out.println(m.mul(65.0 , 5.0));
	}
}
