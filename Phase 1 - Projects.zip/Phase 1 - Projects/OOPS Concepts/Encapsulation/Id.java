package Practice;

public class Id {
	private int id;
	private String name;
	private String Dept;
	private String Mobile;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return Dept;
	}
	public void setDept(String dept) {
		this.Dept = dept;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String Mobile) {
		this.Mobile = Mobile;
	}
	
}
