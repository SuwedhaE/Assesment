package Practice;

public class TestId {
	public static void main(String[] args) {
		Id X = new Id();
		X.setId(3);
		X.setName("Swetha");
		X.setDept("ECE");
		X.setMobile("9878781123");
		
		
		System.out.println("ID : " +X.getId() +"\nName : " + X.getName() + "\nDept : " + X.getDept() + "\nMobile : " + X.getMobile());
		
	}

}
