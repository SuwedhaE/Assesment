package Multithearding;

public class Testsyn {
        public static void main(String[] args) {
		
		Sender sender = new  Sender();
		
		user t1= new user("sai ", "Hello Good morning....!", sender);
		user t2= new user("kavin ","Hii!! how  are you?",sender);
		
		t1.start();
		t2.start();
	}
}
