package Multithearding;

public class Thread1 extends Thread {
	//method over loading
		public void run() {
			System.out.println("thread Started");
		}
		
		public static void main(String[] args) {
			
			Thread1 t1= new Thread1();
			Thread1 t2= new  Thread1();
			
			t1.start();
			t2.start();
		}
}
