package DiamondProb;
interface Demo1  
{  
public default void display()   
{  
System.out.println("the method of Demo1 invoked");  
}  
}  
interface Demo2  
{  
public default void display()   
{  
System.out.println("the method of Demoe2 invoked");  
}  
}  
public class Diaprb implements Demo1, Demo2  
{  
public void display()   
{  
Demo1.super.display();  
Demo2.super.display();  
}  
public static void main(String args[])   
{  
Diaprb obj = new Diaprb();  
obj.display();  
}  
}  