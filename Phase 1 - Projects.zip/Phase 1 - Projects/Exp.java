package CheckedExceptions;

public class Exp {
	public static void main(String[] args) {
		int[] arr = new int[4];
		int i = arr[4];
		try {
			System.out.println("program Executed");
		} catch (Exception e) {
			System.out.println("Exception");
		}
	}
}
