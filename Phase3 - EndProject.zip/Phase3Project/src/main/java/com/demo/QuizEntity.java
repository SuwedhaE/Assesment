package com.demo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class QuizEntity {

	private List<QuestionEntity> questions;

	public List<QuestionEntity> getQuestions() {
		return questions;
	}

	public void setQuestions(List<QuestionEntity> questions) {
		this.questions = questions;
	}

}
