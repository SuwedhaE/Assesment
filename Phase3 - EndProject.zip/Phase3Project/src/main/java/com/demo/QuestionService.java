package com.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QuestionService {
	
	@Autowired
	private QuestionRepository repo;
	

	public QuestionEntity addQuestion(QuestionEntity u) {
		return repo.save(u);
	}
	
	
	
	public List<QuestionEntity> getAllQuestions(){
		return repo.findAll();
	}
	
	
	public QuestionEntity getQuestionsById(int id) {
		if(repo.findById(id).isPresent()) 
			return repo.findById(id).get();
		else 
			return null;
		
	}
	
	public  QuestionEntity updateQues(QuestionEntity user, int id) {
		
		if(repo.findById(id).isPresent())
		{
			QuestionEntity old= repo.findById(id).get();
			old.setQuestion(user.getQuestion());
			old.setOptionA(user.getOptionA());
			old.setOptionB(user.getOptionB());
			old.setOptionC(user.getOptionC());
			old.setOptionD(user.getOptionD());
			old.setAns(user.getAns());
			old.setChoice(user.getChoice());
			
			
			return repo.save(old);
		}
		else
		{
			return null;
		}
		
	}
	
	
	public boolean deleteQues(int id) {
		
		if(repo.findById(id).isPresent())
		{
			repo.deleteById(id);
			return true;
		}
		else
			return false;
	}

}
