package com.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/questions")
public class AdminController {
	
	@Autowired
	private QuestionService service;
	
	@Autowired
	private QuizService service2;
	
	
	@PostMapping("/addQuestions")
	public ResponseEntity<QuestionEntity> addUser(@RequestBody QuestionEntity u){
		QuestionEntity user= service.addQuestion(u);
		if(user!=null)  
			return new ResponseEntity<QuestionEntity>(user,HttpStatus.CREATED);
		else
			return new ResponseEntity<QuestionEntity>(user, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	@GetMapping("/")
	public  List<QuestionEntity> getAllQues(){
		return service.getAllQuestions();
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<QuestionEntity> getQuesById(@PathVariable int id){
		  QuestionEntity user= service.getQuestionsById(id);
		  
		  if(user!=null)
			  return new ResponseEntity<QuestionEntity>(user,HttpStatus.FOUND);
		  else
			  return new  ResponseEntity<QuestionEntity>(user,HttpStatus.NOT_FOUND);
	}
	
	
	@PutMapping("/{id}")
	public ResponseEntity<Object> updateQues(@RequestBody QuestionEntity user,@PathVariable int id){
		QuestionEntity data= service.updateQues(user, id);
		
		if(data!=null)
			return new ResponseEntity<Object>(data,HttpStatus.OK);
		else
			return new ResponseEntity<Object>("User is Not Available",HttpStatus.NOT_FOUND);
	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteQues(@PathVariable  int id ){
		
		if(service.deleteQues(id))
			return new ResponseEntity<Object>("User Deleted", HttpStatus.OK);
		else
			return new ResponseEntity<Object>("No User Found",HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/users")
	public List<ResultEntity> getAllUser(){
		return service2.getTopScore();
	}

}
