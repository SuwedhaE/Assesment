package com.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class QuizService {
	
	@Autowired
	QuestionEntity question;
	@Autowired
	QuizEntity qForm;
	@Autowired
	QuestionRepository qRepo;
	@Autowired
	ResultEntity result;
	@Autowired
	ResultRepository rRepo;
	
	public QuizEntity getQuestions() {
		List<QuestionEntity> allQues = qRepo.findAll();
		List<QuestionEntity> qList = new ArrayList<QuestionEntity>();
		
		Random random = new Random();
		
		for(int i=0; i<20; i++) {
			int rand = random.nextInt(allQues.size());
			qList.add(allQues.get(rand));
			allQues.remove(rand);
		}

		qForm.setQuestions(qList);
		
		return qForm;
	}
	
	public int getResult(QuizEntity qForm) {
		int correct = 0;
		
		for(QuestionEntity q: qForm.getQuestions())
			if(q.getAns() == q.getChoice())
				correct++;
		
		return correct;
	}
	
	public void saveScore(ResultEntity result) {
		ResultEntity saveResult = new ResultEntity();
		saveResult.setUsername(result.getUsername());
		saveResult.setEmail(result.getEmail());
		saveResult.setTotalCorrect(result.getTotalCorrect());
		rRepo.save(saveResult);
	}
	
	public List<ResultEntity> getTopScore() {
		List<ResultEntity> sList = rRepo.findAll(Sort.by(Sort.Direction.DESC, "totalCorrect"));
		return sList;
	}

}
