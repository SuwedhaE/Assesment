package com.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dao.EProductDao;
import com.entity.EProductEntity;

@Controller
public class MainController {

	@Autowired
	EProductDao dao;

	@GetMapping("/viewproduct")
	public String getAllProducts(ModelMap map) {

		List<EProductEntity> list = dao.getAllProducts();
		map.addAttribute("list", list);
		return "viewproduct";

	}
	
	@RequestMapping(value="/editproduct/{id}")    
    public String edit(@PathVariable int id, Model map){    
        EProductEntity entity=dao.getProductById(id);    
        map.addAttribute("command",entity);  
        return "producteditform";    
    }    

	@GetMapping("/editsave")
	public String getProduct(HttpServletRequest request, ModelMap map) {
		long id = Long.parseLong(request.getParameter("id"));
		EProductEntity entity = dao.getProductById(id);
		map.addAttribute("obj", entity);
		return "redirect:/viewproduct";
	}
	
	@RequestMapping("/products")    
    public String showform(Model map){    
        map.addAttribute("command", new EProductEntity());  
        return "products";   
    }    
   
    @RequestMapping(value="/save",method = RequestMethod.POST)    
    public String save(@ModelAttribute("entity") EProductEntity entity){    
        dao.save(entity);    
        return "redirect:/viewproduct";//will redirect to viewemp request mapping    
    }    

}
