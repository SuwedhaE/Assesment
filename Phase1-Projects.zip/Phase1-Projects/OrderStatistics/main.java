package OrderStatistics;

public class main {
public static void main(String[] args) {
		
		kthSmallest ob = new kthSmallest(); 
		
        int arr[] = { 28,23,46,8,5,89,3,0}; 
        
        int left=0;//first index
        
        int n = arr.length;
        
        int right= n-1; //last index
        
        int k = 4; 
        
        System.out.println("K'th smallest element is "+ ob.kthSmallest(arr, left, right, k)); 
    }
}
