package Matrix_Mul;

public class MatrixMultiplication {
public static void main(String[] args) {
		int c2 = 2;
		int c1 = 3;
		int r1 = 2;
		int r2 = 3;
		//int r2=3;
		//int r3=3,c3=3;
		int a[][] = {{3,-2,5},{3,6,4}};
		int b[][] = {{2,3},{-2,6},{3,4}};
		int product[][] = multiplymatrices(a,b,r1,c1,c2);
		displayProduct(product);
	}

	

	private static void displayProduct(int[][] product) {
		System.out.println("Product of two matrices: ");
		for(int[] row:product) {
			for(int col:row) {
				System.out.print(col + " ");
			}
			System.out.println();
		}
	}



	private static int[][] multiplymatrices(int[][] a, int[][] b , int r1 , int c1,int c2) {
		
		int[][] product = new int [r1][c2];
		for (int i=0; i<r1;i++) {
			for(int j = 0;j<c2;j++) {
				for(int k = 0;k<c1;k++) {
					product[i][j] += a[i][k]*b[k][j];
				}
				
			}
		}
		return product;
	}
}

