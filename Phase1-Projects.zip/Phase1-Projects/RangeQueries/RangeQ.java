package RangeQueries;

public class RangeQ {
	public static void main(String[] args) {
		int arr[] = {5,6,7,8,9,3,4};
		int n = arr.length;
		
		RangeQ.buildSparseTable(arr ,n);
		 System.out.println(RangeQ.query(0, 6)); 
	     System.out.println(RangeQ.query(0, 3)); 
	     System.out.println(RangeQ.query(4, 6));
	     System.out.println(RangeQ.query(4, 4)); 
		
		}
	static int N = 10000;
	static int k = 16;
	static long table[][] = new long[N][k+1];
	
	private static void buildSparseTable(int[] arr, int n) {
		for (int i = 0; i < n; i++)
			table[i][0] = arr[i];
		for (int j = 1; j <= k; j++)
			for (int i = 0; i <= n - (1 << j); i++)
				table[i][j] = table[i][j - 1] + table[i + (1 << (j - 1))][j - 1];		
	}
	static long query(int L, int R) {
		long answer = 0;
		for (int j = k; j >= 0; j--) {
			if (L + (1 << j) - 1 <= R) {
				answer = answer + table[L][j];
				L += 1 << j;
			}
		}
		return answer;
	}
}
