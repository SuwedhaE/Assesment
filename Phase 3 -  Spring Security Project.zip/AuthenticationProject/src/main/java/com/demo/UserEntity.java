package com.demo;

public class UserEntity {
	
	private String name;
	private String role;
	private String password;
	
	
	public UserEntity(String name, String role, String password) {
	
		this.name = name;
		this.role = role;
		this.password = password;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
}
