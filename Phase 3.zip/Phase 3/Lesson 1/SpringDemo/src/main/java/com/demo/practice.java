package com.demo;

public class practice {
	
	public void print() {
		System.out.println("Welcome to My WebPage");
	}

}
