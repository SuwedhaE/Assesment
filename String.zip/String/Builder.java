package String;

public class Builder {
public static void main(String[] args) {
		
		String str= new String("Hello World");
		
		StringBuilder s1= new StringBuilder(str);
		
		System.out.println("Size: "+s1.length());
		
		s1.append("Earth");
		System.out.println(s1);
		
		s1.insert(11, " ");
		System.out.println(s1);
		
		s1.replace(12, 15, "see");
		System.out.println(s1);
		
		s1.reverse();
		System.out.println(s1);
		
	}

}
