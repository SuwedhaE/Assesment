package String;

public class StringMethods {
	public static void main(String[] args) {
		 String s1 = new String("Hi Welcome");
		 
		 char c= s1.charAt(5);
		 System.out.println("Character at index 5: "+c);
		 
		 System.out.println("Length: "+s1.length());
		 
		 //uppercase
		 System.out.println("UPPER CASE: "+s1.toUpperCase());
		 //lowercase
		 System.out.println("lowercase: "+s1.toLowerCase());
		 //check the word 
		 System.out.println("Check the String contains word : world or not? : "+s1.contains("Hi"));
		 //sub string 
		 System.out.println("SubString between 3 to 7 characters: "+s1.substring(3,7));
		 
		 String result[]= s1.split(" ");
		 
		 for(String s: result) {
			 System.out.println(s);
		 }
		 
		 //comparison
		 
		 String s2= "hello world";
		
		 if(s1==s2) {
			 System.out.println("Validated");
		 }
		 else {
			 System.out.println("Not Valid");
		 }
		 
	}
}
